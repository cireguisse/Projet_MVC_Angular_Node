﻿'use strict';
var express = require('express');
var router = express.Router();
var evenements = require('../model/evenements');

router.get('/evenements', function (req, res) {
    var result = evenements.getEvenements();
    if (result === 0) {
        return res.status(200).json({
            message: 'Il existe aucun événement'
        });
    }
    return res.status(200).send(result);
});

router.get('/evenements/:acronyme', function (req, res) {
    var evt = evenements.getEvenement(req.params.acronyme);
    if (typeof evt === 'undefined') {
        return res.status(404).json({
            error: 'L\'événement ' + req.params.acronyme + ' n\'existe pas'
        });
    }
    return res.status(200).send(evt);
});

router.post('/evenements', function (req, res) {
    if (typeof req.body.acronyme === 'undefined' || typeof req.body.nom === 'undefined' || typeof req.body.lieu === 'undefined' ||
        typeof req.body.description === 'undefined' || typeof req.body.dateOuverture === 'undefined' || typeof req.body.dateFermeture === 'undefined' ||
        typeof req.body.nbMaxParticipants === 'undefined') {
        return res.status(400).json({
            error: 'Une erreur inconnue -_-\''
        });
    }
    var result = evenements.creerEvenement(req.body.acronyme, req.body.nom, req.body.lieu,
        req.body.description, req.body.dateOuverture, req.body.dateFermeture, req.body.nbMaxParticipants);
    if (result === 0) {
        return res.status(200).json({
            info: 'L\'événement ' + req.body.acronyme + ' existe déjà'
        });
    }
    return res.status(201).json({
        success: 'L\'événement ' + req.body.acronyme + ' a été créer avec succes'
    });
});

router.delete('/evenements/:acronyme', function (req, res) {
    var result = evenements.supprimer(req.params.acronyme);
    if (result === -666) {
        return res.status(500).send();
    }
    if (result === -1) {
        return res.status(404).json({
            info: 'L\'événement ' + req.params.acronyme + ' n\'existe pas'
        });
    }
    if (result === 0) {
        return res.status(404).json({
            error: 'L\'événement ' + req.params.acronyme + ' n\'a pas pu être supprimer'
        });
    }
    else {
        return res.status(200).json({
            success: 'L\'événement ' + req.params.acronyme + ' a été supprimer avec succes'
        });
    }
});

router.post('/evenements/:acronyme', function (req, res) {
    var evt = evenements.getEvenement(req.params.acronyme);
    if (typeof evt === 'undefined') {
        return res.status(404).json({
            error: 'L\'événement ' + req.params.acronyme + ' n\'existe pas'
        });
    }
    else if (typeof req.body.type === 'undefined' || typeof req.body.nbAccompagnantsMax === 'undefined') {
        return res.status(400).send();
    }
    else {  
        var result = evt.ajouterTypeInscription(req.body.type, req.body.nbAccompagnantsMax);
        if (result === 0) {
            return res.status(200).json({
                message: 'Le type d\'inscription existe déjà'
            });
        }
        return res.status(200).json({
            success: 'Type d\'inscription ' + req.body.type + ' ajouter avec succes'
        });
    }
});

router.get('/evenements/:acronyme/participants', function (req, res) {
    var evt = evenements.getEvenement(req.params.acronyme);
    if (typeof evt === 'undefined') {
        return res.status(404).json({
            error: 'L\'événement ' + req.params.acronyme + ' n\'existe pas'
        });
    }
    if (evt.getParticipants() === 0) {
        return res.status(200).json({ info: 'Il n\'y a aucun participants inscrit à l\'évènement' });
    }
    return res.status(200).send(evt.getParticipants());
});

router.get('/evenements/:acronyme/participants/:email', function (req, res) {
    var evt = evenements.getEvenement(req.params.acronyme);
    if (typeof evt === 'undefined') {
        return res.status(404).json({
            error: 'L\'événement ' + req.params.acronyme + ' n\'existe pas'
        });
    }
    if (evt.getParticipant(req.params.email) === 0) {
        return res.status(404).json({ info: 'Le participant ' + req.params.email + ' ne participe pas à cette évènement' });
    }
    return res.status(200).send(evt.getParticipant(req.params.email));
});

router.get('/stats', function (req, res) {
    return res.status(200).json({
        nbEvenements: evenements.getNbEvenements(),
        nbParticipantsMoy: evenements.getNbParticipantsMoy(),
    })
    return res.status(200).send(evenements.stats());
});

router.get('/evenements/:acronyme/stats', function (req, res) {
    var evt = evenements.getEvenement(req.params.acronyme);
    if (typeof evt === 'undefined') {
        return res.status(404).json({
            error: 'L\'événement ' + req.params.acronyme + ' n\'existe pas'
        });
    }
    return res.status(200).send(evt.stats());
});

module.exports = router;