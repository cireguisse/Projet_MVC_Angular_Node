﻿'use strict';
var express = require('express');
var router = express.Router();
var evenements = require('../model/evenements');

router.get('/evenements', function (req, res) {
    var result = evenements.getEvenements();
    if (result === 0) {
        return res.status(200).json({
            message: 'Il existe aucun événement'
        });
    }
    return res.status(200).send(result);
});

router.get('/evenements/:acronyme', function (req, res) {
    var evt = evenements.getEvenement(req.params.acronyme);
    if (typeof evt === 'undefined') {
        return res.status(404).json({
            error: 'L\'événement ' + req.params.acronyme + ' n\'existe pas'
        });
    }
    return res.status(200).send(evt);
});

router.post('/evenements/:acronyme/participants', function (req, res) {
    if (typeof req.body.nom === 'undefined' || typeof req.body.prenom === 'undefined' || typeof req.body.mail === 'undefined' ||
        typeof req.body.tel === 'undefined' || typeof req.body.typeInscription === 'undefined') {
        return res.status(400).send();
    }
    var evt = evenements.getEvenement(req.params.acronyme);
    if (typeof evt === 'undefined') {
        return res.status(404).json({
            error: 'L\'événement ' + req.params.acronyme + ' n\'existe pas'
        });
    }
    var result = evt.inscrireUtilisateur(req.body.nom, req.body.prenom, req.body.mail, req.body.tel, req.body.typeInscription, req.body.supplement);
    if (result === 0) {
        return res.status(200).json({
            error: 'Le type d\'inscription ' + req.body.typeInscription + ' du participant n\'est pas pris en charge par l\'événement ' + req.params.acronyme
        });
    }
    if (result === -1) {
        return res.status(200).json({
            error: 'Le nombre de participant maximal de l\'événement est atteint'
        });
    }
    if (result === -2) {
        return res.status(200).json({
            error: 'Le participant participe déjà à l\'événement'
        });
    }
    return res.status(201).json({
        success: 'Participant inscrit avec succes'
    });
});

router.get('/evenements/:acronyme/typeInscriptions', function (req, res) {
    var evt = evenements.getEvenement(req.params.acronyme);
    if (typeof evt === 'undefined') {
        return res.status(404).json({
            error: 'L\'événement ' + req.params.acronyme + ' n\'existe pas'
        });
    }
    return res.status(200).send(evt.typeInscription);
});

router.post('/evenements/:acronyme/participants/:mail', function (req, res) {
    if (typeof req.body.nom === 'undefined' || typeof req.body.prenom === 'undefined' || typeof req.body.mail === 'undefined' ||
        typeof req.body.tel === 'undefined') {
        return res.status(400).send();
    }
    var evt = evenements.getEvenement(req.params.acronyme);
    if (typeof evt === 'undefined') {
        return res.status(404).json({
            info: 'L\'événement ' + req.params.acronyme + ' n\'existe pas'
        });
    }
    var result = evt.inscrireAccompagnant(req.params.mail, req.body.nom, req.body.prenom, req.body.mail, req.body.tel);
    if (result === -7) {
        return res.status(200).json({
            info: 'Le nombre d\'accompagnant maximal pour ce participant pour cette événement est atteint'
        });
    }
    if (result === -6) {
        return res.status(200).json({
            info: 'Le nombre d\'accompagnant maximal pour ce participant pour cette événement est atteint'
        });
    }
    if (result === -5) {
        return res.status(200).json({
            error: 'Le participant référent n\'est pas inscrit à cette événement'
        });
    }
    if (result === -4) {
        return res.status(200).json({
            info: 'Un participant ne peut pas être accompagnant'
        });
    }
    if (result === -3) {
        return res.status(200).json({
            info: 'Un accompagnant ne peut pas inscire de participant'
        });
    }
    if (result === -2) {
        return res.status(200).json({
            info: 'Un participant est déjà inscrit en tant qu\'accompagnant avec cette adresse mail'
        });
    }
    if (result === -1) {
        return res.status(200).json({
            info: 'Le nombre de participant maximal de l\'événement est atteint'
        });
    }
    if (result === 0) {
        return res.status(200).json({
            info: 'Impossible d\'inscrire l\'accompagnant'
        });
    }
    if (result === 1) {
        return res.status(201).json({
            success: 'Accompagnant inscrit avec succes'
        });
    }
});

router.get('/evenements/:acronyme/participants/:email', function (req, res) {
    var evt = evenements.getEvenement(req.params.acronyme);
    if (typeof evt === 'undefined') {
        return res.status(200).json({
            error: 'L\'événement ' + req.params.acronyme + ' n\'existe pas'
        });
    }
    if (evt.getParticipant(req.params.email) === 0) {
        return res.status(200).json({ info: 'Le participant ' + req.params.email + ' ne participe pas à cette évènement' });
    }
    return res.status(200).send(evt.getParticipant(req.params.email));
});

module.exports = router;