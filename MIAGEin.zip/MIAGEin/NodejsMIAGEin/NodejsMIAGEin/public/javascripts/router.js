﻿'use strict';

angular
    .module('miageIn', [
        'ngAnimate',
        'ngAria',
        'ngCookies',
        'ngMessages',
        'ngResource',
        'ngRoute',
        'ngSanitize',
        'ngTouch'
    ])
    .config(function ($routeProvider) {
        $routeProvider
            .when('/connexion', {
                templateUrl: 'views/connexion.html',
                controller: 'ConnexionCtrl',
                controllerAs: 'connexion'
            })
            .when('/admin', { // La page d'accueil de l'admin
                templateUrl: 'views/admin/accueil.html'
            })
            .when('/admin/creerEvenement', { // Page de création des événements
                templateUrl: 'views/admin/creerEvenement.html',
                controller: 'CreerEvenementCtrl'
            })
            .when('/admin/evenements/:acronyme', { // Affiche un événement donne avec des info admin
                templateUrl: 'views/admin/evenement.html',
                controller: 'AdminEvenementCtrl'
            })
            .when('/admin/evenements', { // Affiche tous événements avec des options d'admin
                templateUrl: 'views/admin/evenements.html',
                controller: 'AdminEvenementsCtrl'
            })
            .when('/admin/supprimerEvenements', { // La page où l'on peut chosir les événements à supprimer
                templateUrl: 'views/admin/supprimerEvenements.html',
                controller: 'SupprimerEvenementsCtrl'
            })
            .when('/admin/statistiquesEvenements', { // La page avec toutes les statistique des événements
                templateUrl: 'views/admin/statistiquesEvenements.html',
                controller: 'StatistiquesCtrl',
                controllerAs: 'statistiques'
            })
            .when('/', { // Page de consultation des événements pour choisir l'événement où s'inscrire
                templateUrl: 'views/user/evenements.html',
                controller: 'EvenementsCtrl',
                controllerAs: 'evenements'
            })
            .when('/evenements', { // Page de consultation des événements pour choisir l'événement où s'inscrire
                templateUrl: 'views/user/evenements.html',
                controller: 'EvenementsCtrl',
                controllerAs: 'evenements'
            })
            .when('/evenements/:acronyme', { // La page où les utilisateurs s'inscrivent
                templateUrl: 'views/user/evenement.html',
                controller: 'EvenementCtrl',
                controllerAs: 'evenement'
            })
            .when('/evenements/:acronyme/accompagnant', { // La page où les utilisateurs s'inscrivent
                templateUrl: 'views/user/accompagnant.html',
                controller: 'AccompagnantCtrl'
            })
            .otherwise({ // La page d'accueil des utilisateurs
                redirectTo: '/'
            });
    });
