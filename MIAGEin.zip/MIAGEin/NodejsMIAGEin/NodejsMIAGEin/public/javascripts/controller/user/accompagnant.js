﻿'use strict';

angular.module('miageIn')
    .controller('AccompagnantCtrl', ['UserFactory', '$routeParams', '$scope', function (UserFactory, $routeParams, $scope) {
        $scope.accompagnant = new UserFactory.Accompagnant;
        $scope.referent = UserFactory;
        console.log($scope.accompagnant);
        console.log($scope.referent.nom === 'undefined');

        $scope.verifier = function () {
            $scope.referent = UserFactory.Accompagnant.get({ acronyme: $routeParams.acronyme, mail: $scope.mail },
                function (msg) {
                    if (typeof msg.success != 'undefined') {
                        $scope.success = msg.success;
                    }
                    if (typeof msg.info != 'undefined') {
                        $scope.info = msg.info;
                    }
                    if (typeof msg.error != 'undefined') {
                        $scope.error = msg.error;
                    }
                },
                function (error) {
                    $scope.error = msg.error;
                });
            console.log($scope.referent);
        }

        $scope.inscrireAccompagnant = function () {
            $scope.accompagnant.$save({ acronyme: $routeParams.acronyme, mail: $scope.referent.mail },
                function (msg) {
                    if (typeof msg.success != 'undefined') {
                        $scope.success2 = msg.success;
                    }
                    if (typeof msg.info != 'undefined') {
                        $scope.info2 = msg.info;
                    }
                    if (typeof msg.error != 'undefined') {
                        $scope.error2 = msg.error;
                    }
                },
                function (error) {
                    $scope.error2 = msg.error;
                });
        }
        console.log($scope.accompagnant);
    }]);