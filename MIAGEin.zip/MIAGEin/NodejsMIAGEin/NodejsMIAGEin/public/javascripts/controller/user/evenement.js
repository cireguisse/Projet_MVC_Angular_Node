﻿'use strict';

angular.module('miageIn')
    .controller('EvenementCtrl', ['UserFactory', '$routeParams', '$scope', function (UserFactory, $routeParams, $scope) {
        $scope.evenement = UserFactory.Evenement.get({ acronyme: $routeParams.acronyme });
        $scope.typeInscriptions = UserFactory.TypeInscriptions.get({ acronyme: $routeParams.acronyme });
        $scope.participant = new UserFactory.InscrireParticipant;
        $scope.accompagnant = new UserFactory.Accompagnant;

        $scope.inscrire = function () {
            $scope.participant.$save({ acronyme: $routeParams.acronyme },
                function (msg) {
                    if (typeof msg.success != 'undefined') {
                        $scope.success = msg.success;
                    }
                    if (typeof msg.info != 'undefined') {
                        $scope.info = msg.info;
                    }
                    if (typeof msg.error != 'undefined') {
                        $scope.error = msg.error;
                    }
                },
                function (error) {
                    console.log(error.data.error);
                }
            );
            $scope.mail = $scope.participant.mail;
        }

        $scope.inscrireAccompagnant = function () {
            console.log($scope.accompagnant);
            $scope.accompagnant.$save({ acronyme: $routeParams.acronyme, mail: $scope.mail },
                function (msg) {
                    if (typeof msg.success != 'undefined') {
                        $scope.success2 = msg.success;
                    }
                    if (typeof msg.info != 'undefined') {
                        $scope.info2 = msg.info;
                    }
                    if (typeof msg.error != 'undefined') {
                        $scope.error2 = msg.error;
                    }
                },
                function (error) {
                    $scope.error2 = msg.error;
                });
        }
    }]);