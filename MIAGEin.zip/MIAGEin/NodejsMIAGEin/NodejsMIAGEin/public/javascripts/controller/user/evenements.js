﻿'use strict';

angular.module('miageIn')
    .controller('EvenementsCtrl', ["UserFactory", function (UserFactory) {
        this.listeEvenements = UserFactory.Evenements.get();
    }]);