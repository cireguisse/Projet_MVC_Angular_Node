﻿'use strict';

angular.module('miageIn')
    .controller('CreerEvenementCtrl', ["$scope", "AdminFactory", function ($scope, AdminFactory) {
        /*
        //marche pas
        delete $scope.success;
        delete $scope.info;
        delete $scope.error;
        */

        $scope.evenement = new AdminFactory.Evenements;
        $scope.typeInscriptions = AdminFactory.TypeInscriptions.get();

        $scope.creer = function () {
            //garde en mémoire l'acronyme de l'événment créer
            $scope.acronyme = $scope.evenement.acronyme;
            $scope.evenement.$save(function (msg) {
                if (typeof msg.success != 'undefined') {
                    $scope.success = msg.success;
                } 
                if (typeof msg.info != 'undefined') {
                    $scope.info = msg.info;
                }
                if (typeof msg.error != 'undefined') {
                    $scope.error = msg.error;
                }
            }, function (error) {
                $scope.error = error.date.error;
                console.log(error.date.error);
            });
        }

        //Desactiver le bouton une fois qu'on a cliquer dessus
        $scope.ajouterTypeInscription = function (typeI) {
            delete $scope.success;
            delete $scope.info;
            delete $scope.error;

            var evt = new AdminFactory.Evenement.get({ acronyme: $scope.acronyme });
            evt.type = typeI.type;
            evt.nbAccompagnantsMax = typeI.nbAccompagnantsMax;
            evt.$ajouterTypeInscription({ acronyme: $scope.acronyme },
                function (msg) {
                    if (typeof msg.success != 'undefined') {
                        $scope.success = msg.success;
                    }
                    if (typeof msg.info != 'undefined') {
                        $scope.info = msg.info;
                    }
                    if (typeof msg.error != 'undefined') {
                        $scope.error = msg.error;
                    }
                },
                function (error) {
                    $scope.error = error.data.error;
                }
             );
        }
    }]);