﻿'use strict';

angular.module('miageIn')
    .controller('StatistiquesCtrl', ["AdminFactory", function (AdminFactory) {

    }]);