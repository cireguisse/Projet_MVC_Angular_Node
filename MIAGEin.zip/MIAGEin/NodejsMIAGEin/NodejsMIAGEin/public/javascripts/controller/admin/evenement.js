﻿'use strict';

angular.module('miageIn')
    .controller('AdminEvenementCtrl', ['AdminFactory', '$routeParams', '$scope', function (AdminFactory, $routeParams, $scope) {
        $scope.evenement = AdminFactory.Evenement.get({ acronyme: $routeParams.acronyme });
        $scope.stats = AdminFactory.EvenementStats.get({ acronyme: $routeParams.acronyme });
        $scope.participants = AdminFactory.EvenementParticipant.get({ acronyme: $routeParams.acronyme },
            function (msg) {
                if (typeof msg.success != 'undefined') {
                    $scope.success = msg.success;
                }
                if (typeof msg.info != 'undefined') {
                    $scope.info = msg.info;
                }
                if (typeof msg.error != 'undefined') {
                    $scope.error = msg.error;
                }
            },
            function (error) {
                $scope.error = error.date.error;
            });
        console.log($scope.participants);
    }]);