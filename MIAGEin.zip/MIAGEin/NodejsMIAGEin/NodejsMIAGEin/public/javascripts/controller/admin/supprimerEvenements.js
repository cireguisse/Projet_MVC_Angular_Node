﻿'use strict';

angular.module('miageIn')
    .controller('SupprimerEvenementsCtrl', ['AdminFactory', '$scope', function (AdminFactory, $scope) {
        $scope.evenements = AdminFactory.Evenements.get();
        $scope.message = 'Supp';
        $scope.supprimer = function (acronyme) {
            AdminFactory.Evenement.delete({ acronyme: acronyme },
                function (msg) {
                    if (typeof msg.success != 'undefined') {
                        $scope.success = msg.success;
                    }
                    if (typeof msg.info != 'undefined') {
                        $scope.info = msg.info;
                    }
                    if (typeof msg.error != 'undefined') {
                        $scope.error = msg.error;
                    }
                }, function (error) {
                    $scope.error = msg.error;
                }
            );
            //actualise la vue
            $scope.evenements = AdminFactory.Evenements.get();
        }
    }]);