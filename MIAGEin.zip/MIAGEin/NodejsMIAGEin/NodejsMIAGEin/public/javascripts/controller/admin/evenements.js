﻿'use strict';

angular.module('miageIn')
    .controller('AdminEvenementsCtrl', ['AdminFactory', '$scope', function (AdminFactory, $scope) {
        $scope.listeEvenements = AdminFactory.Evenements.get();
        $scope.stats = AdminFactory.Stats.get();
    }]);