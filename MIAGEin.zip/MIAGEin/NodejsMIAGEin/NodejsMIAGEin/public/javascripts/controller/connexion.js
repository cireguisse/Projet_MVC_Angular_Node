﻿'use strict';

angular.module('miageIn')
    .controller('ConnexionCtrl', ["AdminFactory", function (AdminFactory) {
        
    }]);