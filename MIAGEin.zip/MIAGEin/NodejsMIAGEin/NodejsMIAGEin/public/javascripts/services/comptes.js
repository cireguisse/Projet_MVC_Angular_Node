﻿angular.module('miageIn').factory('FactoryComptes', function ($resource) {
    return $resource('/comptes/connexion', {});
});