﻿angular.module('miageIn')
    .service('UserFactory', ['$resource', function ($resource) {
        return {
            TypeInscriptions: $resource('/user/typeInscriptions', {}),
            Evenements: $resource('/user/evenements', {}),
            Evenement: $resource('/user/evenements/:acronyme', { acronyme: '@acronyme' }),
            InscrireParticipant: $resource('/user/evenements/:acronyme/participants', { acronyme: '@acronyme' }),
            TypeInscriptions: $resource('/user/evenements/:acronyme/typeInscriptions', { acronyme: '@acronyme'}),
            Accompagnant: $resource('/user/evenements/:acronyme/participants/:mail', { acronyme: '@acronyme', mail: '@mail' })
        };
    }])
    .service('AdminFactory', ['$resource', function ($resource) {
        return {
            TypeInscriptions: $resource('/typeInscriptions', {}),
            Evenements: $resource('/admin/evenements', {}),
            Evenement: $resource('/admin/evenements/:acronyme', { acronyme: '@acronyme' }, {
                // Tester avec le CRUD get, delete et post
                'get': { method: 'GET' },
                'delete': { method: 'DELETE' },
                'ajouterTypeInscription': { method: 'POST' }
            }),
            EvenementStats: $resource('/admin/evenements/:acronyme/stats', { acronyme: '@acronyme' }),
            EvenementParticipant: $resource('/admin/evenements/:acronyme/participants', { acronyme: '@acronyme' }),
            Stats: $resource('/admin/stats', {})
        };
    }]);