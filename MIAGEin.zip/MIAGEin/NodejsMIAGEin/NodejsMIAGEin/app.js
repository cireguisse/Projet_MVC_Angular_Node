﻿'use strict';
var debug = require('debug');
var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var session = require('express-session');
var storage = require('node-persist');

var admin = require('./routes/admin');
var user = require('./routes/user');

var comptes = require('./model/comptes');
var evenements = require('./model/evenements');
comptes.creer('login@email.fr', 'password.fr', 'admin');

storage.initSync();

evenements.creerEvenement('AL3C', 'Truc AL3C', 'Toulouse', 'Présentation des projets', '12/12/2012', '15/12/2012', 10);
evenements.getEvenement('AL3C').ajouterTypeInscription('Etudiant', 1);
evenements.getEvenement('AL3C').ajouterTypeInscription('Professionnel', 2);

var app = express();

app.use(express.static(path.join(__dirname, '/public')));

app.use(favicon(__dirname + '/public/images/favicon.png'));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(session({ secret: '4d54NKN5paunHs28xna90f1knEd', resave: true, saveUninitialized: true }));
app.use(express.static(path.join(__dirname, 'public')));

/* package front-end lien src */
app.use('/angular', express.static(__dirname + '/node_modules/angular'));
app.use('/angular-animate', express.static(__dirname + '/node_modules/angular-animate'));
app.use('/angular-aria', express.static(__dirname + '/node_modules/angular-aria'));
app.use('/angular-cookies', express.static(__dirname + '/node_modules/angular-cookies'));
app.use('/angular-messages', express.static(__dirname + '/node_modules/angular-messages'));
app.use('/angular-resource', express.static(__dirname + '/node_modules/angular-resource'));
app.use('/angular-route', express.static(__dirname + '/node_modules/angular-route'));
app.use('/angular-sanitize', express.static(__dirname + '/node_modules/angular-sanitize'));
app.use('/angular-material', express.static(__dirname + '/node_modules/angular-material'));
app.use('/angular-touch', express.static(__dirname + '/node_modules/angular-touch'));
app.use('/bootstrap', express.static(__dirname + '/node_modules/bootstrap'));
app.use('/jquery', express.static(__dirname + '/node_modules/jquery'));
app.use('/print-js', express.static(__dirname + '/node_modules/print-js'));

app.get('/', function (req, res) {
    return res.status(200).send();
});

app.post('/comptes/connexion', function (req, res) {
    if (comptes.authentifie(req.body.email, req.body.password) === 0) {
        return res.status(404).json({
            error: 'Identifiants incorrect'
        });
    }
    return res.status(201).send();
});

app.use('/admin', admin);
app.use('/user', user);

app.get('/typeInscriptions', function (req, res) {
    return res.status(200).send(evenements.typeInscriptions);
});

// catch 404 and forward to error handler
app.use(function (req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// error handlers

// development error handler
// will print stacktrace
/*if (app.get('env') === 'development') {
    app.use(function (err, req, res, next) {
        res.status(err.status || 500);
        res.render('error', {
            message: err.message,
            error: err
        });
    });
}*/

// production error handler
// no stacktraces leaked to user
/*app.use(function (err, req, res, next) {
    res.status(err.status || 500);
    /*res.render('error', {
        message: err.message,
        error: {}
    });
});*/

app.set('port', process.env.PORT || 3000);

var server = app.listen(app.get('port'), function () {
    debug('Express server listening on port ' + server.address().port);
});
