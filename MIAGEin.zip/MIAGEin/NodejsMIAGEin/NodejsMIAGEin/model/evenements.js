var listeEvenements = {};

var typeInscriptions = {
    'Etudiant': { type: 'Etudiant', nbAccompagnantsMax: 0 },
    'Professeur': { type: 'Professeur', nbAccompagnantsMax: 0 },
    'Administratif': { type: 'Administratif', nbAccompagnantsMax: 0 }
};

function TypeInscription (nbAccompagnantsMax, type) {
    this.nbAccompagnantsMax = nbAccompagnantsMax;
    this.type = type;
}

function Participant(nom, prenom, mail, tel, type, supplement) {
    this.nom = nom;
    this.prenom = prenom;
    this.mail = mail;
    this.tel = tel;
    this.type = type;
    this.accompagnants = {};
    this.supplement = supplement;

    this.creerAccompagnant = function (nom, prenom, mail, tel, supplement) {
        if (typeof this.accompagnants[mail] === 'undefined') {
            this.accompagnants[mail] = new Participant(nom, prenom, mail, tel, this.type, supplement);
            return 1;
        }
        return 0;
    }

    this.getAccompagnant = function (mail) {
        return this.accompagnants[mail];
    }

    this.getNbAccompagnants = function () {
        return Object.keys(this.accompagnants).length;
    }
}

function Evenement(acronyme, nom, lieu, description, dateOuverture,
    dateFermeture, nbMaxParticipants) {
    this.acronyme = acronyme;
    this.nom = nom;
    this.lieu = lieu;
    this.description = description;
    this.dateOuverture = dateOuverture;
    this.dateFermeture = dateFermeture;
    this.nbMaxParticipants = nbMaxParticipants;
    this.typeInscription = {};
    this.participants = {};

    this.ajouterTypeInscription = function (typeInscription, nbAccompagnantsMax) {
        if (typeof this.typeInscription[typeInscription] === 'undefined') {
            this.typeInscription[typeInscription] = new TypeInscription(nbAccompagnantsMax, typeInscription);
            return 1;
        }
        return 0;
    }

    this.getNbParticipants = function () {
        var nb = Object.keys(this.participants).length;
        for (u in this.participants) {
            nb += this.participants[u].getNbAccompagnants();
        }
        return nb;
    }

    this.inscrireUtilisateur = function (nom, prenom, mail, tel, typeInscription, supplement) {
        if (this.getNbParticipants() >= this.nbMaxParticipants) {
            return -1;
        }
        if (typeof this.participants[mail] === 'undefined') {
            if (this.containsType(typeInscription) === 1) {
                this.participants[mail] = new Participant(nom, prenom, mail, tel, typeInscription, supplement);
                return 1;
            }
            else {
                return 0;
            }
        }
        return -2;
    }

    this.inscrireAccompagnant = function (mailU, nom, prenom, mail, tel, supplement) {
        if (this.getNbParticipants() >= this.nbMaxParticipants) {
            return -1;
        }
        for (user in this.participants) {
            if (typeof this.participants[user].getAccompagnant(mail) != 'undefined') {
                return -2;
            }
        }
        for (user in this.participants) {
            if (typeof this.participants[user].getAccompagnant(mailU) != 'undefined') {
                return -3;
            }
        }
        if (this.getParticipant(mail) != 0) {
            return -4;
        }
        if (this.getParticipant(mailU) === 0) {
            return -5;
        }
        if (this.getParticipant(mailU).getNbAccompagnants() >= this.typeInscription[this.getParticipant(mailU).type].nbAccompagnantsMax) {
            return -6;
        }
        var res = this.getParticipant(mailU).creerAccompagnant(nom, prenom, mail, tel, supplement);
        return res;
    }

    this.getTypes = function () {
        return Object.keys(this.typeInscription);
    }

    this.containsType = function (type) {
        if (typeof this.typeInscription[type] === 'undefined') {
            return 0;
        }
        return 1;
    }

    this.getParticipants = function () {
        if (this.getNbParticipants() > 0) {
            return this.participants;
        }
        return 0;
    }

    this.getParticipant = function (mail) {
        if (typeof this.participants[mail] === 'undefined') {
            return 0;
        }
        return this.participants[mail];
    }

    this.stats = function () {
        var liste = {};
        var tmp = {};
        for (t in this.typeInscription) {
            var nbPart = 0;
            var nbAcco = 0;
            for (p in this.participants) {
                if (this.participants[p].type === t) {
                    nbAcco += this.participants[p].getNbAccompagnants();
                    nbPart++;
                }
            }
            var prParticipants = precisionRound((nbPart / this.getNbParticipants()) * 100, 2);
            var prAccompagnant = precisionRound((nbAcco / this.getNbParticipants()) * 100, 2);
            var prTotal = precisionRound(((nbPart + nbAcco) / this.getNbParticipants()) * 100, 2);

            if (isNaN(prParticipants)) {
                prParticipants = 0;
            }
            if (isNaN(prAccompagnant)) {
                prAccompagnant = 0;
            }
            if (isNaN(prTotal)) {
                prTotal = 0;
            }

            liste[t] = {
                type: t,
                nbParticipants: nbPart,
                prParticipants: prParticipants,
                nbAccompagnantsMax: this.typeInscription[t].nbAccompagnantsMax,
                nbAcco: nbAcco,
                prAccompagnant: prAccompagnant,
                total: nbPart + nbAcco,
                prTotal: prTotal
            };
        }
        return liste;
    }
}

/***********************/
/***** Evenements ******/
/***********************/

var creerEvenement = function (acronyme, nom, lieu, description, dateOuverture, dateFermeture, nbMaxParticipants) {
    if (typeof listeEvenements[acronyme] === 'undefined') {
        listeEvenements[acronyme] = new Evenement(acronyme, nom, lieu, description, dateOuverture, dateFermeture, nbMaxParticipants);
            return 1;
    }
    return 0;
}

var getEvenements = function () {
    if (listeEvenements.length === 0) {
        return 0;
    }
    return listeEvenements;
}

var getEvenement = function (acronyme) {
    return listeEvenements[acronyme];
}

var supprimer = function (acronyme) {
    if (typeof listeEvenements[acronyme] === 'undefined') {
        return -1;
    }
    else {
        delete listeEvenements[acronyme];
        if (typeof listeEvenements[acronyme] === 'undefined') {
            return 1;
        }
        else {
            return 0;
        }
    }
    return -666; 
}

var getNbEvenements = function () {
    return Object.keys(listeEvenements).length;
}

var getNbParticipantsMoy = function () {
    var nb = 0;
    for (evt in listeEvenements) {
        nb += listeEvenements[evt].getNbParticipants();
    }
    return (nb / getNbEvenements()) * 100;
}

exports.typeInscriptions = typeInscriptions;
exports.creerEvenement = creerEvenement;
exports.getEvenements = getEvenements;
exports.getEvenement = getEvenement;
exports.supprimer = supprimer;
exports.getNbEvenements = getNbEvenements;
exports.getNbParticipantsMoy = getNbParticipantsMoy;


/**********************/
/* TOOL */

//https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Objets_globaux/Math/round
function precisionRound(number, precision) {
    var factor = Math.pow(10, precision);
    return Math.round(number * factor) / factor;
}