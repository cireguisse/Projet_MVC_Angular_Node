﻿var listeComptes = {};

function Compte(email, password, type) {
    this.email = email;
    this.password = password;
    this.type = type;
}

var creer = function (email, password, type) {
    if (typeof listeComptes[email] === 'undefined') {
        listeComptes[email] = new Compte(email, password, type);
        return 1;
    }
    return 0;
}

/*
-2 si les informations fournis sont fausses
-1 si le compte n'existe pas.
1 si les informations fournis sont exactes
*/
var authentifie = function (email, password, type) {
    if (typeof listeComptes[email] === 'undefined') {
        return 0;
    }
    if (listeComptes[email].password === password) {
        return 1;
    }
    return 0;
}

exports.creer = creer;
exports.authentifie = authentifie;